import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ExperienceSection } from "@/components/experience-section"
import { SkillsSection } from "@/components/skills-section"
import { ServersSection } from "@/components/servers-section"
import { WhyHireSection } from "@/components/why-hire-section"
import { AvailabilitySection } from "@/components/availability-section"
import { ContactSection } from "@/components/contact-section"

export default function Page() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <AboutSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <ExperienceSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <SkillsSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <ServersSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <WhyHireSection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <AvailabilitySection />

        <div className="mx-auto max-w-5xl px-6">
          <hr className="border-border" />
        </div>

        <ContactSection />
      </main>
    </>
  )
}
