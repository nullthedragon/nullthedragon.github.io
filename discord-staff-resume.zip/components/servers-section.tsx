export function ServersSection() {
  const activeServers = [
    {
      name: "dollsies",
      invite: "/dollsies",
      members: "2.1k members",
      role: "Head Admin",
      pfp: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a_d2b6bfa41fa3df6263082f5e2dfb1d88-2KjVYO8ykDvNVLhO05CTNKj5bVSMGI.gif",
      description: "Head admin helping keep the server safe and welcoming for all members.",
    },
    {
      name: "lovenight",
      invite: "/lovenight",
      members: "350+ members",
      role: "Owner",
      pfp: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Lovenight-mHtr0cW14ygm4ociwxt3f3NkW4uezy.png",
      description: "Server owner — built and manage the community from the ground up.",
    },
  ]

  const archivedServers = [
    {
      name: "romance",
      invite: null,
      members: "100k+ members",
      role: "VC Mod (Retired)",
      pfp: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1828-3oVt8QMsPsD7EcgtEUeTE9G3TNTG2R.webp",
      description: "Served as a voice channel moderator in one of Discord's largest romance communities before retiring from the role.",
    },
    {
      name: "pp4y",
      invite: null,
      members: "120k+ members",
      role: "Staff (Retired)",
      pfp: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1829-Hpq8P64Nk7YbObLhtKzCXJdwL95Orx.webp",
      description: "Served as a staff member in a large community before retiring from the role.",
    },
  ]

  return (
    <section id="servers" className="px-6 py-24">
      <div className="mx-auto max-w-5xl">
        <div className="mb-12 text-center">
          <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-primary">
            Server History
          </div>
          <h2 className="text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Servers I Moderate
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-pretty leading-relaxed text-muted-foreground">
            A record of the servers I currently staff and the ones I have contributed to in the past.
          </p>
        </div>

        {/* Active servers */}
        <div className="mb-10">
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-2.5 w-2.5 rounded-full bg-green-500" aria-hidden="true" />
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">Currently Staffing</h3>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {activeServers.map((server) => (
              <div
                key={server.name}
                className="flex items-start gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
              >
                <div className="shrink-0">
                  {server.pfp ? (
                    <img
                      src={server.pfp}
                      alt={`${server.name} server icon`}
                      className="h-14 w-14 rounded-2xl object-cover"
                    />
                  ) : (
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-xl font-bold text-muted-foreground">
                      {server.name[0].toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-foreground">{server.invite}</span>
                    <span className="rounded-full bg-primary/15 px-2.5 py-0.5 text-xs font-medium text-primary">
                      {server.role}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{server.members}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {server.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Archived servers */}
        <div>
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-2.5 w-2.5 rounded-full bg-muted-foreground" aria-hidden="true" />
            <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">Archived / Past Roles</h3>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {archivedServers.map((server) => (
              <div
                key={server.name}
                className="flex items-start gap-4 rounded-xl border border-border bg-card p-5 opacity-70"
              >
                <div className="shrink-0">
                  {server.pfp ? (
                    <img
                      src={server.pfp}
                      alt={`${server.name} server icon`}
                      className="h-14 w-14 rounded-2xl object-cover grayscale"
                    />
                  ) : (
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-xl font-bold text-muted-foreground">
                      {server.name[0].toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-foreground">/{server.name}</span>
                    <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground">
                      {server.role}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{server.members}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {server.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
