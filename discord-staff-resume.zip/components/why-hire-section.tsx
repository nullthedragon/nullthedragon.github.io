const qualities = [
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
    ),
    title: "Reliable",
    description: "You can count on me to show up, follow through, and take my responsibilities seriously.",
  },
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
    ),
    title: "Respectful",
    description: "I treat every member with respect, even when applying consequences — no power tripping.",
  },
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
    ),
    title: "Eager to Learn",
    description: "Every server is different. I adapt quickly, ask questions when unsure, and never guess.",
  },
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
    ),
    title: "Calm Under Pressure",
    description: "I handle conflicts and escalating situations with composure rather than emotion.",
  },
]

export function WhyHireSection() {
  return (
    <section id="why" className="px-6 py-24">
      <div className="mx-auto max-w-5xl">
        <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-primary">
          What I Bring
        </div>
        <h2 className="text-balance text-3xl font-bold text-foreground sm:text-4xl">
          Why I Would Be a Good Fit
        </h2>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          {/* Quote block */}
          <div className="relative rounded-xl border border-primary/30 bg-primary/5 p-8">
            <div
              aria-hidden="true"
              className="absolute -top-3 left-8 text-5xl font-black leading-none text-primary/30 select-none"
            >
              &ldquo;
            </div>
            <blockquote className="mt-4 space-y-4 leading-relaxed text-foreground">
              <p>
                I am reliable, respectful, and willing to learn. I understand how important it is
                to keep a server safe while still making members feel welcome.
              </p>
              <p>
                I can follow staff instructions, handle situations calmly, and ask higher-ups when
                I am unsure instead of guessing.
              </p>
            </blockquote>
            <div className="mt-6 font-semibold text-primary">— Nullthedragon.</div>
          </div>

          {/* Quality cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {qualities.map((q) => (
              <div
                key={q.title}
                className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  {q.icon}
                </div>
                <div>
                  <p className="mb-1 font-semibold text-foreground">{q.title}</p>
                  <p className="text-sm leading-relaxed text-muted-foreground">{q.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
