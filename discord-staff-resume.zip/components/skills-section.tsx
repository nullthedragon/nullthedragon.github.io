const skills = [
  { label: "Discord Moderation", level: "Expert" },
  { label: "Bleed Bot", level: "Proficient" },
  { label: "Ticket Systems", level: "Expert" },
  { label: "Conflict Resolution", level: "Expert" },
  { label: "Member Support", level: "Expert" },
  { label: "Staff Teamwork", level: "Proficient" },
  { label: "Giveaways", level: "Proficient" },
  { label: "Server Safety", level: "Expert" },
  { label: "Communication", level: "Expert" },
  { label: "Activity Checks", level: "Proficient" },
  { label: "Bot Commands", level: "Proficient" },
]

export function SkillsSection() {
  return (
    <section id="skills" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-primary">
          Skills
        </div>
        <h2 className="text-balance text-3xl font-bold text-foreground sm:text-4xl">
          Tools &amp; Abilities
        </h2>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          Technologies, platforms, and soft skills I use every day as a Discord staff member.
        </p>

        <div className="mt-10 flex flex-wrap gap-3">
          {skills.map((skill) => (
            <span
              key={skill.label}
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:border-primary/60 hover:bg-primary/20"
            >
              {skill.level === "Expert" && (
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              )}
              {skill.label}
            </span>
          ))}
        </div>

        <div className="mt-6 flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className="text-primary"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
            Expert
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-primary/40" aria-hidden="true" />
            Proficient
          </span>
        </div>
      </div>
    </section>
  )
}
