const tasks = [
  "Moderation & rule enforcement",
  "Ticket support & member help",
  "Staff task coordination",
  "Server activity & engagement",
  "Event & giveaway assistance",
]

export function AvailabilitySection() {
  return (
    <section id="availability" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="rounded-2xl border border-border bg-card p-8 sm:p-12">
          <div className="grid gap-8 md:grid-cols-2 md:items-center">
            <div>
              <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-primary">
                Availability
              </div>
              <h2 className="text-balance text-3xl font-bold text-foreground sm:text-4xl">
                Ready to Contribute
              </h2>
              <p className="mt-4 leading-relaxed text-muted-foreground">
                I am active on Discord daily and ready to take on staff responsibilities
                in a server that is a good fit.
              </p>

              <div className="mt-6 flex items-center gap-3">
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-green-400" />
                </span>
                <span className="text-sm font-medium text-foreground">
                  Currently available for staff positions
                </span>
              </div>
            </div>

            <ul className="space-y-3">
              {tasks.map((task) => (
                <li key={task} className="flex items-center gap-3 text-sm text-muted-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="shrink-0 text-primary"
                    aria-hidden="true"
                  >
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                  {task}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
