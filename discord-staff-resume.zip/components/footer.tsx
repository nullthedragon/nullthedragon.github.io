export function Footer() {
  return (
    <footer className="border-t border-border px-6 py-8">
      <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-4 text-sm text-muted-foreground sm:flex-row">
        <p>Built for professional Discord staff applications.</p>
        <p>
          &copy; {new Date().getFullYear()}{" "}
          <span className="text-foreground font-medium">Discord Staff Application</span>
        </p>
      </div>
    </footer>
  )
}
