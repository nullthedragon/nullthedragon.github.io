export function AboutSection() {
  const highlights = [
    { icon: "🛡️", label: "Community Safety" },
    { icon: "🎫", label: "Ticket Support" },
    { icon: "🤝", label: "Staff Teamwork" },
    { icon: "📋", label: "Rule Enforcement" },
  ]

  return (
    <section id="about" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="mb-3 text-sm font-semibold uppercase tracking-widest text-primary">
          About Me
        </div>
        <h2 className="text-balance text-3xl font-bold text-foreground sm:text-4xl">
          Who I Am
        </h2>

        <div className="mt-10 grid gap-8 md:grid-cols-2">
          <div className="space-y-4 leading-relaxed text-muted-foreground">
            <p>
              I have experience helping manage Discord communities of all sizes — from small
              hobby servers to larger, more complex communities. I focus on creating environments
              where every member feels safe, heard, and respected.
            </p>
            <p>
              My background includes handling support tickets, keeping chats safe and on-topic,
              helping members with questions, and supporting staff teams with day-to-day tasks.
              I pick up server systems and bots quickly and always look for ways to improve
              the member experience.
            </p>
            <p>
              I believe great moderation is invisible — when staff do their jobs well, members
              simply enjoy being part of the community without ever noticing the work behind it.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {highlights.map((h) => (
              <div
                key={h.label}
                className="flex flex-col gap-2 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
              >
                <span className="text-2xl" aria-hidden="true">{h.icon}</span>
                <span className="text-sm font-semibold text-foreground">{h.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
